package com.kuronami.isekaiapi.client;

import com.kuronami.isekaiapi.IsekaiApi;
import com.kuronami.isekaiapi.api.Isekai;
import com.kuronami.isekaiapi.api.remap.ClientAtmosphereOverride;
import com.kuronami.isekaiapi.api.remap.WorldshapeDescriptor;
import com.kuronami.isekaiapi.network.AtmosphereSyncCache;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ViewportEvent;
import org.jetbrains.annotations.ApiStatus;

/**
 * Applies the active worldshape's {@link ClientAtmosphereOverride} to vanilla rendering via
 * NeoForge's {@link ViewportEvent} hooks. Runs only on the client (the
 * {@link Dist#CLIENT}-annotated subscriber means this class is never loaded on a dedicated
 * server, so no Minecraft / GL references leak into server runtime).
 *
 * <p>For each fog event we read the active descriptor at the camera's current Y (so layered
 * worlds get per-band fog), and apply any non-empty fields:
 *
 * <ul>
 *   <li>{@link ClientAtmosphereOverride#fogColor()} overrides the rendered fog colour.</li>
 *   <li>{@link ClientAtmosphereOverride#fogNearDistance()} sets the start of the fog
 *       gradient (camera-near plane).</li>
 *   <li>{@link ClientAtmosphereOverride#fogFarDistance()} sets the end of the fog gradient
 *       (camera-far plane).</li>
 *   <li>{@link ClientAtmosphereOverride#skyColor()} is applied by
 *       {@code ClientLevelSkyColorMixin} through
 *       {@link #activeSkyColor(ResourceKey, double)}, which replaces only the sampled biome
 *       colour so vanilla's day/night, weather and lightning-flash maths still apply.</li>
 * </ul>
 *
 * <p>Resolution order: when the server has sent an atmosphere for the current dimension (a
 * dedicated server, or the integrated server after login / reload), that copy wins; otherwise
 * the local registry is read as before, which keeps single-player behaviour unchanged before
 * the first payload arrives.
 *
 * <p>Fields not set on the descriptor leave vanilla / biome behaviour untouched.
 */
@ApiStatus.Internal
@EventBusSubscriber(modid = IsekaiApi.MODID, value = Dist.CLIENT)
public final class IsekaiClientAtmosphere {

    private IsekaiClientAtmosphere() {}

    /** Drop the server-sent copy so the next world starts from its own registry. */
    @SubscribeEvent
    public static void onLoggingOut(ClientPlayerNetworkEvent.LoggingOut event) {
        AtmosphereSyncCache.clear();
    }

    @SubscribeEvent
    public static void onComputeFogColor(ViewportEvent.ComputeFogColor event) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        ClientAtmosphereOverride client = activeFor(level.dimension(), event.getCamera().getPosition().y);
        if (client == null) return;
        client.fogColor().ifPresent(rgb -> {
            event.setRed(((rgb >> 16) & 0xFF) / 255.0f);
            event.setGreen(((rgb >> 8) & 0xFF) / 255.0f);
            event.setBlue((rgb & 0xFF) / 255.0f);
        });
    }

    @SubscribeEvent
    public static void onRenderFog(ViewportEvent.RenderFog event) {
        ClientLevel level = Minecraft.getInstance().level;
        if (level == null) return;
        ClientAtmosphereOverride client = activeFor(level.dimension(), event.getCamera().getPosition().y);
        if (client == null) return;
        client.fogNearDistance().ifPresent(event::setNearPlaneDistance);
        client.fogFarDistance().ifPresent(event::setFarPlaneDistance);
    }

    /**
     * Sky colour override active at {@code y} in {@code dimension}, or {@code null} when none
     * applies. Used by {@code ClientLevelSkyColorMixin}; kept here so the resolution order stays
     * identical to the fog hooks. The dimension is passed in rather than read from
     * {@code Minecraft.getInstance()} so a level that is not the current one still resolves
     * against itself.
     */
    public static Integer activeSkyColor(ResourceKey<Level> dimension, double y) {
        ClientAtmosphereOverride client = activeFor(dimension, y);
        return client == null ? null : client.skyColor().orElse(null);
    }

    /**
     * Resolve the {@link ClientAtmosphereOverride} active at the camera's Y. Returns
     * {@code null} when there's no dimension, no descriptor at that Y, or the descriptor has
     * no client-atmosphere overrides set — letting the caller short-circuit.
     *
     * <p>Once the server has sent a payload for {@code dimension}, the band it carries is
     * authoritative (an empty band list means "none"). Falling back to the local registry only
     * while the payload is still unknown keeps single-player unchanged and prevents a stale
     * local declaration from shadowing the server's answer.
     */
    private static ClientAtmosphereOverride activeFor(ResourceKey<Level> dimension, double cameraY) {
        if (dimension == null) return null;
        int y = (int) Math.floor(cameraY);
        if (AtmosphereSyncCache.knows(dimension)) {
            return AtmosphereSyncCache.at(dimension, y).orElse(null);
        }
        WorldshapeDescriptor desc = Isekai.remap().getDescriptorAt(dimension, y).orElse(null);
        if (desc == null) return null;
        ClientAtmosphereOverride client = desc.clientAtmosphere();
        return client.isNoOp() ? null : client;
    }
}
